import { Platform } from "react-native";

const tintColorLight = "#00aadd";
const tintColorDark = "#00aadd";

export const Colors = {
  light: {
    text: "#ffffff",
    textSecondary: "#cccccc",
    buttonText: "#FFFFFF",
    tabIconDefault: "#cccccc",
    tabIconSelected: tintColorLight,
    link: "#00aadd",
    backgroundRoot: "#0f0f12",
    backgroundDefault: "#1a1a1f",
    backgroundSecondary: "#2a2a2f",
    backgroundTertiary: "#353539",
    toggleOff: "#333333",
    toggleOn: "#00aadd",
    border: "#2a2a2f",
  },
  dark: {
    text: "#ffffff",
    textSecondary: "#cccccc",
    buttonText: "#FFFFFF",
    tabIconDefault: "#cccccc",
    tabIconSelected: tintColorDark,
    link: "#00aadd",
    backgroundRoot: "#0f0f12",
    backgroundDefault: "#1a1a1f",
    backgroundSecondary: "#2a2a2f",
    backgroundTertiary: "#353539",
    toggleOff: "#333333",
    toggleOn: "#00aadd",
    border: "#2a2a2f",
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  "4xl": 40,
  "5xl": 48,
  inputHeight: 48,
  buttonHeight: 52,
};

export const BorderRadius = {
  xs: 8,
  sm: 12,
  md: 18,
  lg: 24,
  xl: 30,
  "2xl": 40,
  "3xl": 50,
  full: 9999,
};

export const Typography = {
  h1: {
    fontSize: 32,
    lineHeight: 40,
    fontWeight: "700" as const,
  },
  h2: {
    fontSize: 28,
    lineHeight: 36,
    fontWeight: "700" as const,
  },
  h3: {
    fontSize: 24,
    lineHeight: 32,
    fontWeight: "600" as const,
  },
  h4: {
    fontSize: 20,
    lineHeight: 28,
    fontWeight: "600" as const,
  },
  body: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
  small: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "400" as const,
  },
  link: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
};

export const Fonts = Platform.select({
  ios: {
    /** iOS `UIFontDescriptorSystemDesignDefault` */
    sans: "system-ui",
    /** iOS `UIFontDescriptorSystemDesignSerif` */
    serif: "ui-serif",
    /** iOS `UIFontDescriptorSystemDesignRounded` */
    rounded: "ui-rounded",
    /** iOS `UIFontDescriptorSystemDesignMonospaced` */
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded:
      "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});
