# NAD-min (SNI Stealth) Design Guidelines

## App Overview
NAD-min is a network utility/privacy helper app focused on SNI Privacy Layer management. The app provides a clean, minimal UI for controlling Stealth Mode, configuring network parameters, and monitoring status. All functionality is UI-only (no real network modification) - this is a frontend prototype/mockup.

## Authentication & User Management
**No authentication required** - This is a single-user utility app with local state only.

## Navigation Architecture

### Root Navigation: Bottom Tab Navigation
3 tabs total:
- **Home** - Primary stealth mode control
- **Settings** - Network parameter configuration  
- **Status** - Current state and activity monitoring

No drawer or stack navigation needed beyond the tab structure.

## Screen Specifications

### 1. Home Screen
**Purpose:** Primary control screen for toggling Stealth Mode ON/OFF

**Layout:**
- Header: Default navigation header with "Home" title
- Main content: Centered large circular toggle button
- Non-scrollable fixed layout
- Safe area insets: top (insets.top + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Key Components:**
- Large circular toggle button (primary UI element)
- Current status indicators showing active Host and User-Agent below the button

**Interaction Design:**
- Toggle animates between two states with smooth color transition
- OFF state: Button color #333 (dark gray)
- ON state: Button color #0ad (cyan/turquoise)
- Haptic feedback: 50ms vibration on state change
- Visual feedback: Smooth animated color transition during state change

### 2. Settings Screen
**Purpose:** Configure network parameters for stealth mode

**Layout:**
- Header: Default navigation header with "Settings" title
- Main content: Scrollable form
- Safe area insets: top (insets.top + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Form Components:**
- **Host** input field (text input)
- **User-Agent** input field (text input)
- **Headers** input field (multiline textarea for JSON)
- "Save" button below the form inputs

**Form Behavior:**
- All fields persist to AsyncStorage on Save
- Save button should have visual pressed state
- Clear visual hierarchy between input labels and fields

### 3. Status Screen
**Purpose:** Display current stealth mode state and activity logs

**Layout:**
- Header: Default navigation header with "Status" title
- Main content: Scrollable list/view
- Safe area insets: top (insets.top + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Display Components:**
- **Current Mode**: Stealth ON/OFF indicator (prominent display)
- **Active Configuration Section:**
  - Host value
  - User-Agent value  
  - Headers value
- **Activity Logs Section:**
  - 1-2 mock log entries
  - Each log should show timestamp and brief status message

## Color Palette

### Core Colors
- **Background**: `#0f0f12` (Very dark blue-black)
- **Text Primary**: `#ffffff` (Pure white)
- **Text Secondary**: `#cccccc` (Light gray)
- **Toggle OFF**: `#333333` (Dark gray)
- **Toggle ON**: `#00aadd` (Cyan/turquoise)
- **Input Backgrounds**: Slightly lighter than background (`#1a1a1f` suggested)
- **Borders**: Subtle gray (`#2a2a2f` suggested)

### Theme
Dark mode throughout - no light mode needed.

## Typography
- Use system default fonts (San Francisco for iOS, Roboto for Android)
- Text sizes:
  - Headers: Large/prominent
  - Body text: Medium
  - Input labels: Slightly smaller
- All text should be white (#fff) or gray (#ccc) for legibility on dark background

## Visual Design

### Component Styling
- **Buttons**: Minimalist design with subtle shadows
  - Shadow specifications for floating toggle button:
    - shadowOffset: {width: 0, height: 2}
    - shadowOpacity: 0.10
    - shadowRadius: 2
- **Input fields**: Clean borders, dark backgrounds
- **Tab bar**: Minimalist icons and labels
- **Cards/Containers**: Subtle separation from background, minimal borders

### Icons
- Use Feather icons from @expo/vector-icons
- Tab bar icons should be simple and clear
- NO emojis anywhere in the app

### Animations
- **Home Toggle**: Smooth color transition between states (300-400ms duration)
- All state changes should feel responsive and polished
- Use react-native-reanimated for smooth animations

## Interaction Design

### Haptic Feedback
- Stealth Mode toggle: 50ms vibration on state change
- Settings Save: Optional light haptic confirmation
- All touchable elements should have visual pressed state

### State Management
- All settings persist via AsyncStorage
- App loads previous state on launch
- Real-time UI updates when settings change

## Accessibility Requirements
- Minimum touch target size: 44x44pt for all interactive elements
- Clear visual contrast between interactive and non-interactive elements
- Text should be readable at default system font sizes
- Toggle button should be large enough for easy interaction (minimum 120pt diameter suggested)

## Assets
**No custom assets required** - Use system icons only. The app relies on clean geometric shapes (circular toggle button) and standard iconography from vector icon libraries.

## Technical Notes
- This is a UI prototype/mockup - no real network functionality
- Native bridge functions (applyStealthMode, stopStealthMode) return mock success responses
- Status logs are mock data, not real activity
- All state management is local (AsyncStorage)