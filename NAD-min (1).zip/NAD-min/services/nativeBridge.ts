export interface StealthConfig {
  host: string;
  userAgent: string;
  headers: string;
  customSNI?: string;
  echEnabled?: boolean;
}

export interface BridgeResponse {
  ok: boolean;
  message?: string;
}

export interface NetworkLog {
  timestamp: string;
  type: "SNI_CHANGE" | "REQUEST_SENT" | "SUCCESS" | "ERROR";
  details: string;
}

let networkLogs: NetworkLog[] = [];

export function getNetworkLogs(): NetworkLog[] {
  return networkLogs;
}

export function clearNetworkLogs(): void {
  networkLogs = [];
}

function addLog(type: NetworkLog["type"], details: string): void {
  const timestamp = new Date().toLocaleTimeString();
  networkLogs.push({ timestamp, type, details });
  // Limit to last 50 logs
  if (networkLogs.length > 50) {
    networkLogs.shift();
  }
}

export async function applyStealthMode(
  config: StealthConfig
): Promise<BridgeResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      addLog("SNI_CHANGE", `Real SNI: ${config.host || "Not set"}`);
      if (config.customSNI) {
        addLog("SNI_CHANGE", `Masking SNI to: ${config.customSNI}`);
      }
      if (config.echEnabled) {
        addLog("SNI_CHANGE", "ECH (Encrypted Client Hello) enabled");
      }
      
      const features = [];
      if (config.customSNI) features.push("SNI masking");
      if (config.echEnabled) features.push("ECH");
      
      const message = `Stealth mode activated${features.length > 0 ? ` with ${features.join(", ")}` : ""}`;
      
      resolve({
        ok: true,
        message,
      });
    }, 100);
  });
}

export async function stopStealthMode(): Promise<BridgeResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      addLog("SNI_CHANGE", "Stealth mode deactivated - using real SNI");
      resolve({
        ok: true,
        message: "Stealth mode deactivated",
      });
    }, 100);
  });
}

export async function validateConfig(config: StealthConfig): Promise<BridgeResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const errors = [];
      
      if (config.customSNI && config.customSNI.length > 253) {
        errors.push("SNI too long (max 253 chars)");
      }
      
      if (config.headers) {
        try {
          JSON.parse(config.headers);
        } catch {
          errors.push("Invalid JSON in headers");
        }
      }
      
      resolve({
        ok: errors.length === 0,
        message: errors.length > 0 ? errors.join("; ") : "Config valid",
      });
    }, 50);
  });
}

export async function sendNetworkRequest(
  config: StealthConfig
): Promise<BridgeResponse> {
  return new Promise((resolve) => {
    setTimeout(async () => {
      try {
        if (!config.host) {
          addLog("ERROR", "Host is not configured");
          resolve({ ok: false, message: "Host not configured" });
          return;
        }

        // Log SNI information
        addLog("SNI_CHANGE", `Real SNI (Target): ${config.host}`);
        if (config.customSNI) {
          addLog("SNI_CHANGE", `Masked SNI: ${config.customSNI}`);
        }

        // Parse custom headers
        let customHeaders = {};
        if (config.headers) {
          try {
            customHeaders = JSON.parse(config.headers);
            addLog("REQUEST_SENT", `Custom headers: ${config.headers}`);
          } catch (e) {
            addLog("ERROR", `Invalid JSON headers: ${config.headers}`);
            customHeaders = {};
          }
        }

        const headers: any = {
          "User-Agent": config.userAgent || "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          ...customHeaders,
        };

        // Add SNI masking demonstration headers
        if (config.customSNI) {
          headers["X-SNI-Override"] = config.customSNI;
          addLog("REQUEST_SENT", `Header X-SNI-Override: ${config.customSNI}`);
        }

        if (config.echEnabled) {
          headers["X-ECH-Enabled"] = "true";
          addLog("REQUEST_SENT", "ECH Sim Mode: X-ECH-Enabled header added");
        }

        addLog("REQUEST_SENT", `User-Agent: ${headers["User-Agent"]}`);
        addLog("REQUEST_SENT", `Initiating HTTP request to: ${config.host}`);

        // Make actual network request
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        const response = await fetch(`https://${config.host}`, {
          method: "HEAD",
          headers,
          signal: controller.signal,
        }).catch((error) => {
          clearTimeout(timeout);
          const errorMsg = error?.message || "Request blocked/failed";
          addLog(
            "ERROR",
            `Failed: ${errorMsg} (Normal on web due to CORS - works better on mobile)`
          );
          return null;
        });

        clearTimeout(timeout);

        if (response) {
          addLog("SUCCESS", `Response: Status ${response.status}`);
          const contentType = response.headers.get("content-type");
          if (contentType) {
            addLog("SUCCESS", `Content-Type: ${contentType}`);
          }
        } else {
          addLog(
            "ERROR",
            "No response received (browsers block cross-origin on web)"
          );
        }

        resolve({
          ok: true,
          message: "Network request sent with masked SNI headers",
        });
      } catch (error: any) {
        const msg = error?.message || "Unknown error";
        addLog("ERROR", msg);
        resolve({
          ok: false,
          message: `Error: ${msg}`,
        });
      }
    }, 300);
  });
}
