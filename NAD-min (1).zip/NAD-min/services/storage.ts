import AsyncStorage from "@react-native-async-storage/async-storage";

export interface AppState {
  stealth: boolean;
  host: string;
  userAgent: string;
  headers: string;
  customSNI: string;
  echEnabled: boolean;
}

const STORAGE_KEY = "@nad_min_state";

const defaultState: AppState = {
  stealth: false,
  host: "",
  userAgent: "",
  headers: "{}",
  customSNI: "",
  echEnabled: false,
};

export async function loadState(): Promise<AppState> {
  try {
    const value = await AsyncStorage.getItem(STORAGE_KEY);
    if (value !== null) {
      return JSON.parse(value);
    }
    return defaultState;
  } catch (error) {
    console.error("Error loading state:", error);
    return defaultState;
  }
}

export async function saveState(state: AppState): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error("Error saving state:", error);
  }
}
