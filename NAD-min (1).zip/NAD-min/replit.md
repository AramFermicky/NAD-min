# NAD-min (SNI Stealth)

## Overview

NAD-min is a complete React Native mobile application for managing SNI (Server Name Indication) privacy and masking. The app provides a comprehensive interface for masking your real domain behind a trusted CDN or service. Built with Expo and React Native, the app supports iOS, Android, and web platforms with a dark-themed UI.

The application features four main screens accessible via bottom tab navigation:
- **Home**: Large toggle button for activating/deactivating Stealth Mode
- **Settings**: Configure network parameters (Host, Custom SNI, User-Agent, Headers, ECH)
- **Status**: Monitor current configuration and real network activity with detailed logging
- **Guide**: Complete interactive tutorial with SNI theory, setup instructions, and examples

## Complete Functionality

### SNI Masking System
The app implements a complete SNI masking system that:
- Takes your real domain (Host) and masks it behind a trusted SNI domain (Custom SNI)
- Sends real HTTP requests with masked SNI headers
- Applies custom User-Agent and HTTP headers to requests
- Supports ECH (Encrypted Client Hello) for additional privacy
- Provides real-time logging of all operations

### Network Request Engine
- Real HTTP/HTTPS requests with customizable headers
- X-SNI-Override header for SNI masking demonstration
- X-ECH-Enabled header for ECH Sim Mode
- 5-second timeout with proper error handling
- CORS-aware (graceful fallback on web browsers)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Platform**
- Built with React Native 0.81.5 and Expo SDK 54
- Cross-platform support for iOS, Android, and web
- React 19.1.0 with React Compiler enabled for optimization
- TypeScript for type safety with strict mode enabled

**Navigation Structure**
- Bottom tab navigation as the root navigation pattern (no drawer or stack navigation)
- Three main tabs: Home, Settings, and Status
- Custom header titles with app icon integration
- Platform-specific blur effects for iOS tab bar (using BlurView from expo-blur)
- Transparent headers on iOS, solid background on Android/web

**UI Component Architecture**
- Theme system based on `useTheme` hook with dark color scheme
- Reusable themed components (`ThemedView`, `ThemedText`) that respect color scheme
- Animated components using `react-native-reanimated` for smooth transitions
- Custom screen wrapper components (`ScreenScrollView`, `ScreenKeyboardAwareScrollView`, `ScreenFlatList`) that handle safe area insets and keyboard avoidance
- Centralized design tokens in `constants/theme.ts` for spacing, colors, typography, and border radius

**Animation & Interactions**
- Reanimated 4.1.1 for declarative animations with worklets
- Spring-based animations for button press feedback (scale animations)
- Color interpolation for smooth toggle state transitions
- Haptic feedback on user interactions (using expo-haptics)
- Platform-aware haptics (disabled on web)

**State Management**
- React Context API via `AppContext` for global app state
- Local state stored and persisted using AsyncStorage
- State includes: stealth mode status, host, user-agent, headers, custom SNI, ECH enabled flag
- Automatic state persistence on updates

**Safe Area & Layout Handling**
- Custom `useScreenInsets` hook calculates proper padding based on header height, tab bar height, and safe area insets
- Consistent padding across all screens using the insets hook
- Keyboard-aware scrolling on Settings screen (falls back to regular ScrollView on web)

**Error Handling**
- Error boundary component wrapping the entire app
- Custom error fallback UI with development-mode error details
- Modal for viewing full error stack traces in development
- App restart functionality on errors

### Core Features & Design Patterns

**Stealth Mode Toggle**
- Large circular button (140px) as primary UI element on Home screen
- Two-state toggle with animated color transition (dark gray when OFF, cyan when ON)
- State changes trigger native bridge calls to apply/stop stealth configuration
- Haptic feedback and smooth animations enhance user experience

**Network Configuration**
- Text inputs for Host, User-Agent, Headers (JSON string), and Custom SNI Override
- Settings persist automatically when saved via AsyncStorage
- Validation happens at the native bridge layer (currently mocked)

**Custom SNI Override Feature**
- Allows users to specify a replacement SNI to mask the real SNI when stealth mode is active
- Home screen displays both "Реальный SNI" (Real SNI from host field) and "Замаскированный SNI" (Stealthed SNI from customSNI field)
- When stealth mode is OFF, the stealthed SNI appears in gray with "(не активно)" indicator
- When stealth mode is ON, the stealthed SNI displays in normal color without the inactive indicator
- Status screen shows SNI Configuration section with both Real SNI and Stealthed SNI values
- Visual feedback changes dynamically based on stealth mode state

**ECH Sim Mode (Encrypted Client Hello)**
- Toggle switch in Settings screen to enable/disable ECH Sim mode
- ECH status displayed on Home screen showing whether it's enabled or disabled
- When stealth mode is OFF, ECH status appears in gray with "(не активно)" indicator
- Status screen shows Privacy Features section with ECH Sim Mode configuration
- ECH state persisted automatically via AsyncStorage
- Ready for integration with real ECH implementation

**Network Request Functionality**
- Real HTTP request sending with custom headers based on SNI configuration
- Logging system that tracks all SNI changes, requests, and responses
- Detailed network activity logs showing timestamp, type, and details
- Request headers include X-SNI-Override and X-ECH-Enabled for demonstration
- Supports both successful responses and graceful error handling
- Network logs persist during session (limited to 50 entries)

**Real SNI Implementation**
- `sendNetworkRequest()` function sends actual fetch requests with masked SNI headers
- Logs all steps: real SNI detection, masking application, header formation, request sending
- When Stealth Mode is ON with custom SNI, requests include X-SNI-Override header
- Custom User-Agent and JSON headers are applied to all requests
- ECH Sim Mode adds X-ECH-Enabled header when enabled
- Real-time logging shows exactly what SNI and headers are being used
- Web version may encounter CORS restrictions (expected behavior)

**Native Bridge with Logging**
- Service layer (`services/nativeBridge.ts`) provides full SNI manipulation interface
- Logs SNI changes when Stealth Mode toggles on/off
- Supports real network requests with custom SNI masking
- Built-in config validation for SNI length (max 253 chars) and JSON headers
- Network activity log system with type categorization (SNI_CHANGE, REQUEST_SENT, SUCCESS, ERROR)
- Ready for integration with actual native modules when needed

**Status Monitoring**
- Real-time display of current stealth mode state
- SNI Configuration section showing Real SNI and Stealthed SNI with stealth mode awareness
- Privacy Features section displaying ECH Sim Mode status
- Network Configuration section displaying User-Agent and Headers
- Network Activity section with "Test SNI" button to send real requests
- Real network activity logs with color coding (yellow for SNI changes, green for success, red for errors)
- Clear Logs button to reset activity history
- Inactive state indicators ("не активно") when stealth mode is disabled

## Complete Feature List

### ✅ Implemented Features

1. **SNI Masking**
   - Real Host (target domain) field
   - Custom SNI Override field for masking
   - Support for any domain (recommended: CDN domains)

2. **User Configuration**
   - Custom User-Agent spoofing
   - JSON headers support for custom HTTP headers
   - Referer, Accept-Language, and other header customization
   - All settings persist automatically via AsyncStorage

3. **ECH Sim Mode** 
   - Toggle for Encrypted Client Hello simulation
   - Adds X-ECH-Enabled header to requests
   - Provides additional privacy layer

4. **Real Network Operations**
   - Actual HTTP requests to configured hosts
   - Custom header application
   - Real-time network activity demonstration
   - Supports both successful responses and graceful error handling

5. **Advanced Logging System**
   - Color-coded event types (SNI_CHANGE, REQUEST_SENT, SUCCESS, ERROR)
   - Detailed request information (headers, SNI values, timestamps)
   - Last 50 logs stored in memory
   - Clear logs functionality

6. **Interactive Guide**
   - 5-section tabbed guide within the app
   - SNI theory and background
   - Step-by-step setup instructions
   - Real-world examples and best practices
   - Troubleshooting section
   - Live testing walkthrough

7. **Haptic Feedback**
   - Toggle press feedback on mobile devices
   - Network request sending feedback
   - Platform-aware (disabled on web)

8. **Stealth Mode Toggle**
   - Large 140px circular button on Home screen
   - Smooth color animations (dark gray ↔ cyan)
   - State-aware display of Real SNI and Masked SNI
   - Automatic logging of stealth mode changes

## External Dependencies

### Core Framework & Runtime
- **Expo SDK 54**: Development platform and build tooling
- **React Native 0.81.5**: Cross-platform mobile framework
- **React Navigation 7**: Bottom tab navigation with native stack

### UI & Animation Libraries
- **react-native-reanimated**: Smooth animations for toggle and transitions
- **react-native-gesture-handler**: Touch gesture handling
- **react-native-safe-area-context**: Safe area inset management
- **react-native-keyboard-controller**: Keyboard handling for Settings inputs
- **expo-blur**: iOS blur effects for tab bar
- **expo-glass-effect**: Platform-specific glass morphism effects
- **expo-haptics**: Haptic feedback on user interactions

### Storage & State
- **@react-native-async-storage/async-storage**: Persistent state storage

### Platform-Specific
- **expo-status-bar**: Status bar management
- **expo-splash-screen**: Splash screen handling
- **expo-web-browser**: In-app browser (future use)
- **expo-symbols**: Platform-specific icons

### Development Tools
- **TypeScript**: Full type safety
- **ESLint** + Expo config: Code linting
- **Prettier**: Code formatting
- **babel-plugin-module-resolver**: `@/` path aliasing

### Build & Deployment
- Custom build script for Replit static deployment
- Environment variable handling for proxy configuration
- QR code generation for Expo Go testing

## Documentation Files

**SNI_SETUP_GUIDE.md** - Comprehensive user guide including:
- SNI theory and background
- Step-by-step configuration instructions
- Real-world usage examples
- Recommended SNI domains and why they work
- Log interpretation guide
- Troubleshooting section
- Best practices for privacy and security