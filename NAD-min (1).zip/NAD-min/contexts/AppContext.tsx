import React, { createContext, useContext, useState, useEffect } from "react";
import { AppState, loadState, saveState } from "@/services/storage";
import {
  applyStealthMode,
  stopStealthMode,
  sendNetworkRequest,
  getNetworkLogs,
  clearNetworkLogs,
  NetworkLog,
} from "@/services/nativeBridge";

interface AppContextType {
  state: AppState;
  toggleStealth: () => Promise<void>;
  updateSettings: (settings: Partial<AppState>) => Promise<void>;
  isLoading: boolean;
  sendTestRequest: () => Promise<void>;
  networkLogs: NetworkLog[];
  clearLogs: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>({
    stealth: false,
    host: "",
    userAgent: "",
    headers: "{}",
    customSNI: "",
    echEnabled: false,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [networkLogs, setNetworkLogs] = useState<NetworkLog[]>([]);

  useEffect(() => {
    loadInitialState();
  }, []);

  const loadInitialState = async () => {
    const loadedState = await loadState();
    setState(loadedState);
    setIsLoading(false);
  };

  const toggleStealth = async () => {
    const newStealth = !state.stealth;
    
    if (newStealth) {
      await applyStealthMode({
        host: state.host,
        userAgent: state.userAgent,
        headers: state.headers,
        customSNI: state.customSNI,
        echEnabled: state.echEnabled,
      });
    } else {
      await stopStealthMode();
    }

    const newState = { ...state, stealth: newStealth };
    setState(newState);
    await saveState(newState);
  };

  const updateSettings = async (settings: Partial<AppState>) => {
    const newState = { ...state, ...settings };
    setState(newState);
    await saveState(newState);
  };

  const sendTestRequest = async () => {
    if (!state.host) {
      alert("Please set a host in Settings first");
      return;
    }
    
    await sendNetworkRequest({
      host: state.host,
      userAgent: state.userAgent,
      headers: state.headers,
      customSNI: state.customSNI,
      echEnabled: state.echEnabled,
    });
    
    // Update logs display
    setNetworkLogs([...getNetworkLogs()]);
  };

  const clearLogs = () => {
    clearNetworkLogs();
    setNetworkLogs([]);
  };

  return (
    <AppContext.Provider
      value={{
        state,
        toggleStealth,
        updateSettings,
        isLoading,
        sendTestRequest,
        networkLogs,
        clearLogs,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useAppContext must be used within AppProvider");
  }
  return context;
}
