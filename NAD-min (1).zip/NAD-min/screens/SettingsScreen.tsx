import React, { useState } from "react";
import { View, StyleSheet, TextInput, Pressable, Platform, Switch } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { Spacing, Colors } from "@/constants/theme";
import { useAppContext } from "@/contexts/AppContext";
import * as Haptics from "expo-haptics";

export default function SettingsScreen() {
  const { state, updateSettings } = useAppContext();
  const [host, setHost] = useState(state.host);
  const [userAgent, setUserAgent] = useState(state.userAgent);
  const [headers, setHeaders] = useState(state.headers);
  const [customSNI, setCustomSNI] = useState(state.customSNI);
  const [echEnabled, setEchEnabled] = useState(state.echEnabled);

  const handleSave = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    await updateSettings({ host, userAgent, headers, customSNI, echEnabled });
  };

  return (
    <ScreenKeyboardAwareScrollView style={styles.container}>
      <View style={styles.content}>
        <ThemedText style={styles.sectionTitle}>Network Settings</ThemedText>

        <View style={styles.inputGroup}>
          <ThemedText style={styles.label}>Host</ThemedText>
          <TextInput
            style={styles.input}
            value={host}
            onChangeText={setHost}
            placeholder="Enter host (e.g., example.com)"
            placeholderTextColor={Colors.dark.textSecondary}
          />
        </View>

        <View style={styles.inputGroup}>
          <ThemedText style={styles.label}>User-Agent</ThemedText>
          <TextInput
            style={styles.input}
            value={userAgent}
            onChangeText={setUserAgent}
            placeholder="Enter custom User-Agent"
            placeholderTextColor={Colors.dark.textSecondary}
          />
        </View>

        <View style={styles.inputGroup}>
          <ThemedText style={styles.label}>Custom SNI Override</ThemedText>
          <TextInput
            style={styles.input}
            value={customSNI}
            onChangeText={setCustomSNI}
            placeholder="Enter custom SNI (e.g., cdn-whatsapp-01.com)"
            placeholderTextColor={Colors.dark.textSecondary}
          />
        </View>

        <View style={styles.inputGroup}>
          <ThemedText style={styles.label}>Headers (JSON)</ThemedText>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={headers}
            onChangeText={setHeaders}
            placeholder='{"Content-Type": "application/json"}'
            placeholderTextColor={Colors.dark.textSecondary}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>

        <View style={styles.toggleGroup}>
          <View style={styles.toggleRow}>
            <View style={styles.toggleLabelContainer}>
              <ThemedText style={styles.label}>ECH Sim Mode</ThemedText>
              <ThemedText style={styles.toggleHint}>
                Encrypted Client Hello
              </ThemedText>
            </View>
            <Switch
              value={echEnabled}
              onValueChange={setEchEnabled}
              trackColor={{ false: Colors.dark.border, true: Colors.dark.toggleOn }}
              thumbColor={echEnabled ? Colors.dark.text : Colors.dark.textSecondary}
            />
          </View>
        </View>

        <Pressable
          style={({ pressed }) => [
            styles.saveButton,
            pressed && styles.saveButtonPressed,
          ]}
          onPress={handleSave}
        >
          <ThemedText style={styles.saveButtonText}>Save Settings</ThemedText>
        </Pressable>
      </View>
    </ScreenKeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    marginBottom: Spacing.xl,
    color: Colors.dark.text,
  },
  inputGroup: {
    marginBottom: Spacing.xl,
  },
  label: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
    marginBottom: Spacing.sm,
  },
  input: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    borderRadius: 8,
    padding: Spacing.md,
    fontSize: 16,
    color: Colors.dark.text,
  },
  textArea: {
    minHeight: 100,
    paddingTop: Spacing.md,
  },
  saveButton: {
    backgroundColor: Colors.dark.toggleOn,
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.xl,
    borderRadius: 8,
    alignItems: "center",
    marginTop: Spacing.xl,
  },
  saveButtonPressed: {
    opacity: 0.7,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.dark.text,
  },
  toggleGroup: {
    marginBottom: Spacing.xl,
    marginTop: Spacing.xl,
  },
  toggleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: Colors.dark.backgroundDefault,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    borderRadius: 8,
    padding: Spacing.md,
  },
  toggleLabelContainer: {
    flex: 1,
    marginRight: Spacing.md,
  },
  toggleHint: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
    marginTop: Spacing.xs,
  },
});
