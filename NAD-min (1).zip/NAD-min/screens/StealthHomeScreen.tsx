import React from "react";
import { View, StyleSheet, Pressable, Platform } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Spacing, Colors } from "@/constants/theme";
import { useAppContext } from "@/contexts/AppContext";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  withTiming,
  interpolateColor,
} from "react-native-reanimated";

const tabBarHeight = 49;
const TOGGLE_SIZE = 140;

export default function StealthHomeScreen() {
  const insets = useSafeAreaInsets();
  const { state, toggleStealth } = useAppContext();

  const handleToggle = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    await toggleStealth();
  };

  const animatedStyle = useAnimatedStyle(() => {
    const backgroundColor = interpolateColor(
      state.stealth ? 1 : 0,
      [0, 1],
      [Colors.dark.toggleOff, Colors.dark.toggleOn]
    );

    return {
      backgroundColor: withTiming(backgroundColor, { duration: 300 }),
    };
  });

  return (
    <ThemedView
      style={[
        styles.container,
        {
          paddingTop: insets.top + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
        },
      ]}
    >
      <View style={styles.content}>
        <Pressable onPress={handleToggle}>
          <Animated.View style={[styles.toggleButton, animatedStyle]}>
            <ThemedText style={styles.toggleText}>
              {state.stealth ? "ON" : "OFF"}
            </ThemedText>
          </Animated.View>
        </Pressable>

        <View style={styles.infoContainer}>
          <View style={styles.sniSection}>
            <View style={styles.infoRow}>
              <ThemedText style={styles.infoLabel}>Реальный SNI:</ThemedText>
              <ThemedText style={styles.infoValue} numberOfLines={1}>
                {state.host || "—"}
              </ThemedText>
            </View>
            <View style={styles.infoRow}>
              <ThemedText style={styles.infoLabel}>
                Замаскированный SNI:
              </ThemedText>
              <ThemedText
                style={[
                  styles.infoValue,
                  !state.stealth && styles.inactiveText,
                ]}
                numberOfLines={1}
              >
                {state.customSNI || "—"}
                {!state.stealth && state.customSNI
                  ? " (не активно)"
                  : ""}
              </ThemedText>
            </View>
          </View>
          <View style={styles.echSection}>
            <View style={styles.infoRow}>
              <ThemedText style={styles.infoLabel}>ECH Sim Mode:</ThemedText>
              <ThemedText
                style={[
                  styles.infoValue,
                  !state.stealth && styles.inactiveText,
                ]}
              >
                {state.echEnabled ? "Enabled" : "Disabled"}
                {!state.stealth && state.echEnabled ? " (не активно)" : ""}
              </ThemedText>
            </View>
          </View>
        </View>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
  },
  toggleButton: {
    width: TOGGLE_SIZE,
    height: TOGGLE_SIZE,
    borderRadius: TOGGLE_SIZE / 2,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 4,
  },
  toggleText: {
    fontSize: 28,
    fontWeight: "700",
    color: Colors.dark.text,
  },
  infoContainer: {
    marginTop: Spacing["4xl"],
    width: "100%",
    maxWidth: 400,
  },
  infoRow: {
    marginBottom: Spacing.lg,
  },
  infoLabel: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
    marginBottom: Spacing.xs,
  },
  infoValue: {
    fontSize: 16,
    color: Colors.dark.text,
  },
  sniSection: {
    width: "100%",
    marginBottom: Spacing.lg,
  },
  echSection: {
    width: "100%",
    paddingTop: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: Colors.dark.border,
  },
  inactiveText: {
    color: Colors.dark.textSecondary,
  },
});
