import React, { useState } from "react";
import { View, StyleSheet, Pressable, Platform } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { Spacing, Colors } from "@/constants/theme";
import { useAppContext } from "@/contexts/AppContext";
import * as Haptics from "expo-haptics";

export default function StatusScreen() {
  const { state, sendTestRequest, networkLogs, clearLogs } = useAppContext();
  const [isSending, setIsSending] = useState(false);

  const handleSendRequest = async () => {
    setIsSending(true);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    await sendTestRequest();
    setIsSending(false);
  };

  return (
    <ScreenScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Current Mode</ThemedText>
          <View style={styles.statusCard}>
            <View style={styles.statusRow}>
              <View
                style={[
                  styles.statusIndicator,
                  {
                    backgroundColor: state.stealth
                      ? Colors.dark.toggleOn
                      : Colors.dark.toggleOff,
                  },
                ]}
              />
              <ThemedText style={styles.statusText}>
                Stealth Mode: {state.stealth ? "ON" : "OFF"}
              </ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>SNI Configuration</ThemedText>
          <View style={styles.configCard}>
            <View style={styles.configRow}>
              <ThemedText style={styles.configLabel}>Real SNI:</ThemedText>
              <ThemedText style={styles.configValue}>
                {state.host || "Not configured"}
              </ThemedText>
            </View>
            <View style={styles.configRow}>
              <ThemedText style={styles.configLabel}>Stealthed SNI:</ThemedText>
              <ThemedText
                style={[
                  styles.configValue,
                  !state.stealth && styles.inactiveValue,
                ]}
              >
                {state.customSNI || "Not configured"}
                {!state.stealth && state.customSNI ? " (не активно)" : ""}
              </ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Privacy Features</ThemedText>
          <View style={styles.configCard}>
            <View style={styles.configRow}>
              <ThemedText style={styles.configLabel}>ECH Sim Mode:</ThemedText>
              <ThemedText
                style={[
                  styles.configValue,
                  !state.stealth && styles.inactiveValue,
                ]}
              >
                {state.echEnabled ? "Enabled" : "Disabled"}
                {!state.stealth && state.echEnabled ? " (не активно)" : ""}
              </ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText style={styles.sectionTitle}>Network Configuration</ThemedText>
          <View style={styles.configCard}>
            <View style={styles.configRow}>
              <ThemedText style={styles.configLabel}>User-Agent:</ThemedText>
              <ThemedText style={styles.configValue} numberOfLines={2}>
                {state.userAgent || "Not configured"}
              </ThemedText>
            </View>
            <View style={styles.configRow}>
              <ThemedText style={styles.configLabel}>Headers:</ThemedText>
              <ThemedText
                style={[styles.configValue, styles.monoText]}
                numberOfLines={3}
              >
                {state.headers || "{}"}
              </ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.testButtonRow}>
            <ThemedText style={styles.sectionTitle}>Network Activity</ThemedText>
            <Pressable
              style={({ pressed }) => [
                styles.testButton,
                pressed && styles.testButtonPressed,
                isSending && styles.testButtonDisabled,
              ]}
              onPress={handleSendRequest}
              disabled={isSending}
            >
              <ThemedText style={styles.testButtonText}>
                {isSending ? "Sending..." : "Test SNI"}
              </ThemedText>
            </Pressable>
          </View>
          
          {networkLogs.length > 0 && (
            <Pressable
              style={({ pressed }) => [
                styles.clearButton,
                pressed && styles.clearButtonPressed,
              ]}
              onPress={clearLogs}
            >
              <ThemedText style={styles.clearButtonText}>Clear Logs</ThemedText>
            </Pressable>
          )}

          {networkLogs.length === 0 ? (
            <ThemedText style={styles.noLogsText}>
              No network activity yet. Tap "Test SNI" to send a request.
            </ThemedText>
          ) : (
            networkLogs.map((log, index) => (
              <View
                key={index}
                style={[
                  styles.logCard,
                  log.type === "ERROR" && styles.logCardError,
                  log.type === "SUCCESS" && styles.logCardSuccess,
                  log.type === "SNI_CHANGE" && styles.logCardSNI,
                ]}
              >
                <ThemedText style={styles.logTimestamp}>
                  {log.timestamp}
                </ThemedText>
                <ThemedText style={styles.logType}>[{log.type}]</ThemedText>
                <ThemedText style={styles.logMessage}>{log.details}</ThemedText>
              </View>
            ))
          )}
        </View>
      </View>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: Spacing.xl,
  },
  section: {
    marginBottom: Spacing["3xl"],
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    marginBottom: Spacing.lg,
    color: Colors.dark.text,
  },
  statusCard: {
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: Spacing.md,
  },
  statusText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.dark.text,
  },
  configCard: {
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  configRow: {
    marginBottom: Spacing.md,
  },
  configLabel: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
    marginBottom: Spacing.xs,
  },
  configValue: {
    fontSize: 16,
    color: Colors.dark.text,
  },
  monoText: {
    fontFamily: "monospace",
    fontSize: 14,
  },
  logCard: {
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: Spacing.md,
  },
  logTimestamp: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
    marginBottom: Spacing.xs,
  },
  logMessage: {
    fontSize: 14,
    color: Colors.dark.text,
  },
  inactiveValue: {
    color: Colors.dark.textSecondary,
  },
  testButtonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  testButton: {
    backgroundColor: Colors.dark.toggleOn,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: 6,
  },
  testButtonPressed: {
    opacity: 0.7,
  },
  testButtonDisabled: {
    opacity: 0.5,
  },
  testButtonText: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.dark.text,
  },
  clearButton: {
    backgroundColor: Colors.dark.toggleOff,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: 6,
    marginBottom: Spacing.lg,
    alignItems: "center",
  },
  clearButtonPressed: {
    opacity: 0.7,
  },
  clearButtonText: {
    fontSize: 12,
    fontWeight: "600",
    color: Colors.dark.text,
  },
  noLogsText: {
    fontSize: 14,
    color: Colors.dark.textSecondary,
    fontStyle: "italic",
    padding: Spacing.lg,
    textAlign: "center",
  },
  logType: {
    fontSize: 11,
    color: Colors.dark.toggleOn,
    fontWeight: "600",
    marginBottom: Spacing.xs,
  },
  logCardError: {
    borderLeftWidth: 3,
    borderLeftColor: "#ff6b6b",
  },
  logCardSuccess: {
    borderLeftWidth: 3,
    borderLeftColor: Colors.dark.toggleOn,
  },
  logCardSNI: {
    borderLeftWidth: 3,
    borderLeftColor: "#ffd700",
  },
});
