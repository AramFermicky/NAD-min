import React, { useState } from "react";
import { View, StyleSheet, Pressable, ScrollView } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { Spacing, Colors } from "@/constants/theme";

type Section = 
  | "overview" 
  | "setup" 
  | "examples" 
  | "troubleshoot" 
  | "practice";

export default function GuideScreen() {
  const [activeSection, setActiveSection] = useState<Section>("overview");

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return (
          <View>
            <ThemedText style={styles.heading}>Что такое SNI?</ThemedText>
            <ThemedText style={styles.paragraph}>
              SNI (Server Name Indication) - это часть TLS handshake, где клиент
              сообщает серверу, какой hostname нужен. Провайдер видит эту информацию.
            </ThemedText>

            <ThemedText style={styles.subheading}>Как это работает:</ThemedText>
            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>Без маскировки:</ThemedText>
              <ThemedText style={styles.code}>
                Клиент → TLS: SNI=example.com → Провайдер видит example.com
              </ThemedText>
            </View>

            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>С маскировкой:</ThemedText>
              <ThemedText style={styles.code}>
                Клиент → TLS: SNI=cdn.google.com → Провайдер видит Google
              </ThemedText>
            </View>

            <ThemedText style={styles.paragraph}>
              NAD-min маскирует SNI, выглядя как трафик к популярному сервису,
              скрывая реальный сайт, который вы посещаете.
            </ThemedText>
          </View>
        );

      case "setup":
        return (
          <View>
            <ThemedText style={styles.heading}>Правильная настройка</ThemedText>

            <ThemedText style={styles.subheading}>Шаг 1: Host (Реальный SNI)</ThemedText>
            <ThemedText style={styles.label}>Это настоящий сайт, который вы посещаете</ThemedText>
            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>Пример: example.com</ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Шаг 2: Custom SNI Override</ThemedText>
            <ThemedText style={styles.label}>Это домен, под который вы маскируетесь</ThemedText>
            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>Рекомендуемые:</ThemedText>
              <ThemedText style={styles.code}>• cdn.google.com</ThemedText>
              <ThemedText style={styles.code}>• cdn.cloudflare.com</ThemedText>
              <ThemedText style={styles.code}>• akamai.com</ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Шаг 3: User-Agent (опционально)</ThemedText>
            <ThemedText style={styles.label}>Информация о вашем браузере/устройстве</ThemedText>
            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>Пример:</ThemedText>
              <ThemedText style={[styles.code, styles.monoSmall]}>
                Mozilla/5.0 (Windows; U; Windows NT)...
              </ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Шаг 4: Headers (опционально)</ThemedText>
            <ThemedText style={styles.label}>Дополнительные HTTP заголовки</ThemedText>
            <View style={styles.codeBlock}>
              <ThemedText style={styles.code}>{`{`}</ThemedText>
              <ThemedText style={styles.code}>  "Referer": "https://google.com",</ThemedText>
              <ThemedText style={styles.code}>  "Accept-Language": "en-US"</ThemedText>
              <ThemedText style={styles.code}>{`}`}</ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Шаг 5: ECH Sim Mode</ThemedText>
            <ThemedText style={styles.label}>Включите для дополнительной приватности</ThemedText>
            <ThemedText style={styles.paragraph}>
              Это добавляет Encrypted Client Hello заголовок для дополнительной защиты.
            </ThemedText>
          </View>
        );

      case "examples":
        return (
          <View>
            <ThemedText style={styles.heading}>Примеры использования</ThemedText>

            <ThemedText style={styles.subheading}>Пример 1: Базовая маскировка</ThemedText>
            <View style={styles.exampleCard}>
              <ThemedText style={styles.exampleLabel}>Host:</ThemedText>
              <ThemedText style={styles.exampleValue}>example.com</ThemedText>
              <ThemedText style={styles.exampleLabel}>Custom SNI:</ThemedText>
              <ThemedText style={styles.exampleValue}>cdn.google.com</ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Пример 2: С User-Agent</ThemedText>
            <View style={styles.exampleCard}>
              <ThemedText style={styles.exampleLabel}>Host:</ThemedText>
              <ThemedText style={styles.exampleValue}>blocked-site.com</ThemedText>
              <ThemedText style={styles.exampleLabel}>Custom SNI:</ThemedText>
              <ThemedText style={styles.exampleValue}>cdn.cloudflare.com</ThemedText>
              <ThemedText style={styles.exampleLabel}>User-Agent:</ThemedText>
              <ThemedText style={[styles.exampleValue, styles.monoSmall]}>
                Mozilla/5.0 (Windows NT 10.0)
              </ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Пример 3: Полная настройка</ThemedText>
            <View style={styles.exampleCard}>
              <ThemedText style={styles.exampleLabel}>Host:</ThemedText>
              <ThemedText style={styles.exampleValue}>restricted-site.org</ThemedText>
              <ThemedText style={styles.exampleLabel}>Custom SNI:</ThemedText>
              <ThemedText style={styles.exampleValue}>akamai.com</ThemedText>
              <ThemedText style={styles.exampleLabel}>Headers:</ThemedText>
              <ThemedText style={[styles.exampleValue, styles.monoSmall]}>
                {`{"Referer":"https://google.com"}`}
              </ThemedText>
              <ThemedText style={styles.exampleLabel}>ECH Mode:</ThemedText>
              <ThemedText style={styles.exampleValue}>Enabled</ThemedText>
            </View>

            <ThemedText style={styles.subheading}>Лучшие SNI для маскировки:</ThemedText>
            <View style={styles.bulletList}>
              <ThemedText style={styles.bullet}>🔵 cdn.google.com (очень популярный)</ThemedText>
              <ThemedText style={styles.bullet}>🔵 cdn.cloudflare.com (альтернатива)</ThemedText>
              <ThemedText style={styles.bullet}>🔵 akamai.com (ещё одна опция)</ThemedText>
              <ThemedText style={styles.bullet}>🔵 fastly.com (для видео)</ThemedText>
            </View>
          </View>
        );

      case "troubleshoot":
        return (
          <View>
            <ThemedText style={styles.heading}>Решение проблем</ThemedText>

            <ThemedText style={styles.subheading}>
              ❌ Ошибка "CORS policy"
            </ThemedText>
            <ThemedText style={styles.paragraph}>
              Это нормально для веб-версии. Браузер блокирует cross-origin
              запросы. На мобильных устройствах в Expo Go будет работать
              лучше.
            </ThemedText>

            <ThemedText style={styles.subheading}>
              ❌ Запрос не отправляется
            </ThemedText>
            <ThemedText style={styles.paragraph}>
              1. Проверьте что Host и Custom SNI заполнены
              2. Убедитесь что Stealth Mode включен
              3. Посмотрите логи на Status экране
            </ThemedText>

            <ThemedText style={styles.subheading}>
              ❌ SNI блокируется провайдером
            </ThemedText>
            <ThemedText style={styles.paragraph}>
              1. Используйте более популярные SNI (Google, Cloudflare)
              2. Меняйте SNI регулярно
              3. Добавьте realistic User-Agent
              4. Включите ECH Mode
            </ThemedText>

            <ThemedText style={styles.subheading}>
              ℹ️ Как проверить что работает?
            </ThemedText>
            <View style={styles.bulletList}>
              <ThemedText style={styles.bullet}>
                1. Откройте Status экран
              </ThemedText>
              <ThemedText style={styles.bullet}>
                2. Посмотрите все ли заполнено в SNI Configuration
              </ThemedText>
              <ThemedText style={styles.bullet}>
                3. Нажмите "Test SNI" кнопку
              </ThemedText>
              <ThemedText style={styles.bullet}>
                4. Смотрите логи - они покажут точно что отправляется
              </ThemedText>
            </View>
          </View>
        );

      case "practice":
        return (
          <View>
            <ThemedText style={styles.heading}>Тестирование</ThemedText>

            <ThemedText style={styles.subheading}>Быстрый старт:</ThemedText>
            <View style={styles.stepCard}>
              <ThemedText style={styles.stepNumber}>1</ThemedText>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Settings</ThemedText>
                <ThemedText style={styles.stepText}>
                  Host: www.google.com
                </ThemedText>
                <ThemedText style={styles.stepText}>
                  Custom SNI: cdn.cloudflare.com
                </ThemedText>
              </View>
            </View>

            <View style={styles.stepCard}>
              <ThemedText style={styles.stepNumber}>2</ThemedText>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Home</ThemedText>
                <ThemedText style={styles.stepText}>
                  Нажмите кнопку Stealth Mode (OFF → ON)
                </ThemedText>
              </View>
            </View>

            <View style={styles.stepCard}>
              <ThemedText style={styles.stepNumber}>3</ThemedText>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Status</ThemedText>
                <ThemedText style={styles.stepText}>
                  Нажмите "Test SNI" кнопку
                </ThemedText>
              </View>
            </View>

            <View style={styles.stepCard}>
              <ThemedText style={styles.stepNumber}>4</ThemedText>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Логи</ThemedText>
                <ThemedText style={styles.stepText}>
                  Смотрите Network Activity логи
                </ThemedText>
              </View>
            </View>

            <ThemedText style={styles.subheading}>Что вы увидите в логах:</ThemedText>
            <View style={styles.logExample}>
              <ThemedText style={[styles.logLine, styles.logSNI]}>
                [SNI_CHANGE] Real SNI: www.google.com
              </ThemedText>
              <ThemedText style={[styles.logLine, styles.logSNI]}>
                [SNI_CHANGE] Masking SNI to: cdn.cloudflare.com
              </ThemedText>
              <ThemedText style={[styles.logLine, styles.logRequest]}>
                [REQUEST_SENT] Sending request to: www.google.com
              </ThemedText>
              <ThemedText style={[styles.logLine, styles.logRequest]}>
                [REQUEST_SENT] Using masked SNI: cdn.cloudflare.com
              </ThemedText>
              <ThemedText style={[styles.logLine, styles.logSuccess]}>
                [SUCCESS] Response received
              </ThemedText>
            </View>

            <ThemedText style={styles.success}>
              ✅ Если вы видите логи - приложение работает!
            </ThemedText>
          </View>
        );
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.tabsContainer}
      >
        <Pressable
          style={[styles.tab, activeSection === "overview" && styles.tabActive]}
          onPress={() => setActiveSection("overview")}
        >
          <ThemedText style={styles.tabText}>Что это?</ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, activeSection === "setup" && styles.tabActive]}
          onPress={() => setActiveSection("setup")}
        >
          <ThemedText style={styles.tabText}>Настройка</ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, activeSection === "examples" && styles.tabActive]}
          onPress={() => setActiveSection("examples")}
        >
          <ThemedText style={styles.tabText}>Примеры</ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, activeSection === "troubleshoot" && styles.tabActive]}
          onPress={() => setActiveSection("troubleshoot")}
        >
          <ThemedText style={styles.tabText}>Проблемы</ThemedText>
        </Pressable>
        <Pressable
          style={[styles.tab, activeSection === "practice" && styles.tabActive]}
          onPress={() => setActiveSection("practice")}
        >
          <ThemedText style={styles.tabText}>Тест</ThemedText>
        </Pressable>
      </ScrollView>

      <ScreenScrollView style={styles.contentContainer}>
        <View style={styles.content}>{renderContent()}</View>
      </ScreenScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabsContainer: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
    paddingHorizontal: Spacing.sm,
  },
  tab: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  tabActive: {
    borderBottomColor: Colors.dark.toggleOn,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.dark.text,
  },
  contentContainer: {
    flex: 1,
  },
  content: {
    padding: Spacing.xl,
  },
  heading: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.dark.text,
    marginBottom: Spacing.lg,
  },
  subheading: {
    fontSize: 18,
    fontWeight: "600",
    color: Colors.dark.toggleOn,
    marginTop: Spacing.lg,
    marginBottom: Spacing.md,
  },
  paragraph: {
    fontSize: 14,
    color: Colors.dark.text,
    lineHeight: 22,
    marginBottom: Spacing.md,
  },
  label: {
    fontSize: 13,
    color: Colors.dark.textSecondary,
    marginBottom: Spacing.sm,
    fontStyle: "italic",
  },
  codeBlock: {
    backgroundColor: Colors.dark.backgroundDefault,
    borderLeftWidth: 3,
    borderLeftColor: Colors.dark.toggleOn,
    padding: Spacing.md,
    borderRadius: 6,
    marginBottom: Spacing.lg,
  },
  code: {
    fontSize: 12,
    color: Colors.dark.text,
    fontFamily: "monospace",
    lineHeight: 18,
  },
  monoSmall: {
    fontSize: 11,
  },
  exampleCard: {
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: Spacing.lg,
  },
  exampleLabel: {
    fontSize: 12,
    color: Colors.dark.textSecondary,
    fontWeight: "600",
    marginTop: Spacing.md,
    marginBottom: Spacing.xs,
  },
  exampleValue: {
    fontSize: 14,
    color: Colors.dark.toggleOn,
    fontFamily: "monospace",
  },
  bulletList: {
    marginVertical: Spacing.lg,
  },
  bullet: {
    fontSize: 14,
    color: Colors.dark.text,
    marginBottom: Spacing.md,
    lineHeight: 20,
  },
  stepCard: {
    flexDirection: "row",
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: Spacing.md,
  },
  stepNumber: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.dark.toggleOn,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.dark.border,
    textAlign: "center",
    textAlignVertical: "center",
    marginRight: Spacing.lg,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.dark.text,
    marginBottom: Spacing.sm,
  },
  stepText: {
    fontSize: 13,
    color: Colors.dark.textSecondary,
    lineHeight: 18,
  },
  logExample: {
    backgroundColor: Colors.dark.backgroundDefault,
    padding: Spacing.lg,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginVertical: Spacing.lg,
  },
  logLine: {
    fontSize: 11,
    fontFamily: "monospace",
    lineHeight: 16,
    marginBottom: Spacing.xs,
  },
  logSNI: {
    color: "#ffd700",
  },
  logRequest: {
    color: Colors.dark.text,
  },
  logSuccess: {
    color: Colors.dark.toggleOn,
  },
  success: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.dark.toggleOn,
    padding: Spacing.lg,
    backgroundColor: Colors.dark.backgroundDefault,
    borderRadius: 8,
    overflow: "hidden",
    marginTop: Spacing.lg,
    textAlign: "center",
  },
});
